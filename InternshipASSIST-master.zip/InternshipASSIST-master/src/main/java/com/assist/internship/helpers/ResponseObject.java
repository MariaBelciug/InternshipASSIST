package com.assist.internship.helpers;

public interface ResponseObject {

}
